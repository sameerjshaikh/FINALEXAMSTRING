package exam.hello;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class B {

	private C obj1;

	@Autowired
	public void setObj1(C obj1) {
		System.out.println("Service : repository DAO  wired to service ");
		this.obj1 = obj1;
	}

	public B() {

		// System.out.println("B object created");
	}

	// single select scenario public Device getMobile(int mn) { // note obj1 here
	// is a repository object

	Contact getdevid(int mn) {

		Optional<Contact> x = obj1.findById(mn);
		Contact y = null;
		if (x.isPresent()) {
			return x.get(); // get the mobile object

		} else

		{
			y = new Contact("not found", 0, 0); // logic is mobile object iemi no

			return y;

		}

		// }

		/*
		 * public Device updateMobile(Device n)
		 * 
		 * {
		 * 
		 * 
		 * if(obj1.existsById(n.getDeviceid()))
		 * 
		 * 
		 * obj1.save(n); //change of failing is almost zero. else
		 * 
		 * 
		 * System.out.println("update failed");
		 * 
		 * return n; }
		 * 
		 * 
		 */

		/*
		 * public List<Mobile> getAll() { // TODO Auto-generated method stub return
		 * obj1.findAll(); }
		 */

		/*
		 * public boolean deletethroughquery(int mn) {
		 * 
		 * if( obj1.existsById(mn)) { obj1.deleteById(mn);
		 * 
		 * return ; }
		 * 
		 * else { return false; }
		 * 
		 * 
		 * }
		 */

		/*
		 * public Device getdevid(int devid)
		 *  { Optional<Device> o =
		 * obj1.findById(devid); Device d= null; if(o.isPresent()) {
		 * 
		 * d = o.get(); return d;
		 * 
		 * }
		 * 
		 * else { d = new Device(0,"",0); return d;
		 * 
		 * }
		 * 
		 * }
		 */

		/*
		 * public List<Device> getms(String name) {
		 * 
		 * 
		 * 
		 * return obj1.get(name);
		 * 
		 * 
		 * }
		 */

	}

	public Contact updateconatact(Contact n) {
         
		if( obj1.existsById(n.getMbileno()))
		{
			System.out.println(" updated");
			
			obj1.save(n);
			return n;
		}
		else {
			System.out.println("update failed");
			return n;
		}
		
		
		
		
		
		
	}
}
