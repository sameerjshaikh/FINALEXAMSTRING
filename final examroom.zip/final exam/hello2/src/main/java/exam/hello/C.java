package exam.hello;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface C extends JpaRepository<Contact, Integer> {
	
	//Mobile is entity class, Integer is primary key
	// hibernate will never work until you use concept called Primary key.
	
	
	/*
	 * @Query("delete u from mobile u where u.mn = y") boolean
	 * deleteql(@Param("y")int mn);
	 */
	
	
	//@Query("SELECT u FROM Mobile u WHERE u.imeino = 3")
	//Collection<Mobile> findAllActiveUsers();
		

	/*
	 * @Query("from mobile where deviceid = :x")
	 *  Device findme(@Param("x") int mn);
	 * 
	 * 
	 * 
	 */
	
	/*
	 * @Query("SELECT u FROM Mobile u WHERE u.name = :name") List<Device>
	 * findAllActiveUsers(@Param("y") String name);
	 */
	
	        
}
