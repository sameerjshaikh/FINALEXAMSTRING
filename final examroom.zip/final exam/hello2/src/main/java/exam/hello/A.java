package exam.hello;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@CrossOrigin(origins = "*")
@RestController
public class A {
	
	private B obj1;
	
	public A()
	{
		////System.out.println("A object created");
		
	}
	
	
	@Autowired
	public void setObj1(B obj1) {
		System.out.println("Controller : service is wired with Controller ");
		this.obj1 = obj1;
	}


//http:localhost:8080?x=1
	
	//http://localhost:8080/pw?x=1
	
	//http://localhost:8080/pw?x=10, you will get mobile no as zero
	
	/*
	 * @GetMapping("/find") public Device f1(@RequestParam("x")int id)//assume
	 * single select {
	 * 
	 * Device d =obj1.getMobile(id); return d;
	 * 
	 * }
	 */
	  
	  
	
	  @PostMapping("/upd")
	  public Contact f2(@RequestBody Contact n) //assume single
	  {
	  
	  
	  Contact m =obj1.updateconatact(n); 
	  return m;
	  
	  }
	 
	  
	/*
	 * @GetMapping("/ms") //multiselect public List<Mobile> get() { List<Mobile> x
	 * =obj1.getAll(); return x;
	 * 
	 * }
	 * 
	 * 
	 * @GetMapping("/dql") Mobile querydelete(@RequestParam("z") int mn) {
	 * 
	 * 
	 * obj1.deletethroughquery(mn); Mobile m=null;
	 * 
	 * return m;
	 * 
	 * 
	 * }
	 */
	 
	
	@GetMapping("/did")
	Contact getobject(@RequestParam("x")  int mobno)
	{
		
      Contact d = obj1.getdevid(mobno);
		
		return d;
	}
	
	/*
	 * @GetMapping("/ms") List<Device> f3(@RequestParam("ch") String name) {
	 * 
	 * List< Device> div = obj1.getms(name); return div;
	 * 
	 * }
	 */
	
	


}
