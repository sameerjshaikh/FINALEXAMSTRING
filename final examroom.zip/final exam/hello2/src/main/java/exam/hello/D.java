package exam.hello;

import java.util.List;

import org.springframework.web.client.RestTemplate;

public class D {

	
	//please before running D.java ensure server is running.
	
	public static void main(String[] args) {
		// suppose postman goes to post office
		String url ="http://localhost:7700";
		RestTemplate t =new RestTemplate();
		
		 Contact x = t.getForObject(url+"/did?x=286",Contact.class);
		  System.out.println(x);
		  
		  
		  
		
		  Contact z = new Contact("B",421,286); 
		  Contact d = t.postForObject(url+"/upd", z,
		  Contact.class);
		  
		  
		  
		 
		  
		  
		  
		  
		/*
		 * try {
		 * 
		 * 
		 * t.getForObject(url+"/dql?z=2",Mobile.class ); }
		 * 
		 * catch(Exception e) {
		 * 
		 * e.getStackTrace(); }
		 * 
		 * 
		 * 
		 */
		  
		  /*
		
		  List l = t.getForObject(url+"/ms",List.class); 
		  
		  System.out.println(l.size());
		 
		
		  Mobile z =new Mobile(67,77);
		  Mobile q =  t.postForObject("http://localhost:8080/upd", z, Mobile.class);
		  System.out.println(q);
		  
		  
		  
		  */
		

	}

}
