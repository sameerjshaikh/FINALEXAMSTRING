package ds.basics;

import java.util.Comparator;

public class IdBasedComparator implements Comparator<Device> {

	@Override
	public int compare(Device o1, Device o2) {
		// TODO Auto-generated method stub
		return o1.getDeviceid() - o2.getDeviceid();
	}

}
