package ds.basics;

public class Device {
	
	private int deviceid, status;
	private String deviceName;
	public int getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(int deviceid) {
		this.deviceid = deviceid;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public Device(int deviceid, int status, String deviceName) {
		super();
		this.deviceid = deviceid;
		this.status = status;
		this.deviceName = deviceName;
	}
	public Device() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Device (deviceid=" + deviceid + ", status=" + status + ", deviceName=" + deviceName + ")";
	}
	@Override
	public boolean equals(Object obj) {
		// what is true or false programmer decides and not java.
		
		Device x = (Device) obj;
		if(deviceid == x.deviceid)
			return true;
		else
			return false;
		
		
		
		
		
	}
	
	

}
