package ds.basics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestList {
	
	public static void main(String[] args) {
		
		List<Circle> c =new ArrayList<Circle>();
		c.add(new Circle(12));
		c.add(new Circle(3));
		Collections.sort(c);
		System.out.println(c);
		
		
		 List<Device> d =new ArrayList();
		 d.add(new Device(1,2,"A"));
		 d.add(new Device(23,2,"B"));
		 d.add(new Device(3,1,"C"));
		 
		 Comparator<Device> x = new StatusBasedComparator();
		 
		 Comparator<Device> y = new IdBasedComparator();

		 d.sort(x);  //sort based on status
		 
		 d.sort(y);  //sort based on id
		 
		 
		 
		
		
		
	}
	
	public static void main2(String[] args) {
		
		List<String>  l =new ArrayList<String>();
		l.add("hello");
		l.add("fine");
		String x ="hello";
		int pos = l.indexOf(x);
		if( pos > -1)
		{
			String s ="HI"; //new object required becuase string is immutable.
			l.set(pos, s); 
			
		}
		
		
	}
	
	 public static void main1(String[] args) {
		
		 List<Device> d =new ArrayList();
		 d.add(new Device(1,2,"A"));
		 d.add(new Device(23,2,"B"));
		 d.add(new Device(3,1,"C"));
		 
		 
		 System.out.println(d);
		 
		 Device toFind =new Device(23,24,"D");
		 
		 int pos = d.indexOf(toFind);
		 
		 if( pos != -1)
		 {
			Device x = d.get(pos);
			x.setStatus(44);  //status changed of the object
			 System.out.println("Found at pos " + pos);
			 
		 }
		 else
			 System.out.println("not found");
		 
		 System.out.println("after modif" + d);
		 
		 
 		 
	}
	
	

}
