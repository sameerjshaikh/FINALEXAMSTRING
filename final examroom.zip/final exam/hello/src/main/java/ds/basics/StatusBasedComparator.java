package ds.basics;

import java.util.Comparator;

public class StatusBasedComparator implements Comparator<Device> {

	@Override
	public int compare(Device o1, Device o2) {
		// TODO Auto-generated method stub
		return o1.getStatus() - o2.getStatus();
	}

}
