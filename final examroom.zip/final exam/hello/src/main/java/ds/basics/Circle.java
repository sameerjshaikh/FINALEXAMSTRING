package ds.basics;

public class Circle implements Comparable<Circle>{
	
	private int r;
	
	

	public Circle(int r) {

		this.r = r;
	}

	public int getR() {
		return r;
	}

	

	public Circle() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Circle [r=" + r + "]";
	}

	@Override
	public int compareTo(Circle arg0) {
		// java tells you decide what is big, what is small and what is equal
		// I will use it for sorting
		//pos this is bigger than input , neg this is smaller than input or zero both ar eequa;
		return r-arg0.r ;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
