package exam.hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@CrossOrigin(origins = "*")
@RestController
public class A {
	
	private B obj1;
	
	public A()
	{
		////System.out.println("A object created");
		
	}
	
	
	@Autowired
	public void setObj1(B obj1) {
		System.out.println("Controller : service is wired with Controller ");
		this.obj1 = obj1;
	}


//http:localhost:8080?x=1
	
	//http://localhost:8080/pw?x=1
	
	//http://localhost:8080/pw?x=10, you will get mobile no as zero
	
	@GetMapping("/pw")
	public Mobile f1(@RequestParam("x")int mn)//assume single select
	{
		System.out.println("function pw is getting called");
		Mobile m =obj1.getMobile(mn);
		return m;
		
	}
	
	
	@GetMapping("/nps")
	public Mobile f3(@RequestParam("x")int imeino)//assume single select
	{
		System.out.println("function pw is getting called");
		Mobile m =obj1.getMobileOk(imeino);
		return m;
		
	}
	
	
	@GetMapping("/non")
	public Mobile f4(@RequestParam("x")int imeino)//assume single select
	{
		System.out.println("function pw is getting called");
		Mobile m =obj1.getNonID(imeino);
		return m;
		
	}
	
	@GetMapping("/del")
	public Mobile f5(@RequestParam("x")int mn)//assume single select
	{
		System.out.println("function pw is getting called");
		Mobile m =obj1.getdeletfun(mn);
		return m;
		
	}
	
	
	
	
	@PostMapping("/aoinhypsdpoc")
	public Rectangle postWhoCares(@RequestBody Circle c )
	{
		Rectangle r =new Rectangle();
		r.setLength(c.getRadius()+1);
		r.setBreadth(c.getRadius()+2);
		return r;
		
	}
	
	
	
	
	
	
	
	
	
	@PostMapping("/upd")
	public Mobile f2(@RequestBody Mobile n)//assume single select
	{
	
		
		Mobile m =obj1.updateMobile(n);
		return m;
		
	}
	
	@GetMapping("/ms") //multiselect
	public List<Mobile> get()
	{
		List<Mobile> x =obj1.getAll();
		return x;
		
	}
	@GetMapping("/msq") //multiselect
	public List<Mobile> msget(@RequestParam("x")int imeino)
	{
		List<Mobile> x =obj1.getAllmsget(imeino);
		return x;
		
	}
	
	

	
	
	
	
	

}
