package exam.hello;

import java.util.List;

import org.springframework.web.client.RestTemplate;

public class D {

	
	//please before running D.java ensure server is running.
	
	public static void main(String[] args) {
		// suppose postman goes to post office
	//	String url ="http://localhost:7700/aoinhypsdpoc";
		RestTemplate t =new RestTemplate();
	/*	
		Circle c = new Circle();  //input
		c.setRadius(3);
		Rectangle r = t.postForObject(url, c, Rectangle.class);
		System.out.println(r.getLength());
		
		 */
		
		  String url ="http://localhost:7777";
		  
		  
		  /*
		 * Mobile x = t.getForObject(url+"/pw?x=2",Mobile.class);
		 * System.out.println(x.getImeino());
		 */
		
		  
		  
		
		/*
		 * Mobile x = t.getForObject(url+"/non?x=33333",Mobile.class);
		 * System.out.println(x.getMn());
		 */
		
		
		
		  //for delete
		
		  try {
		       Mobile x =t.getForObject(url+"/del?x=1",Mobile.class);
		       System.out.println("This "+ x +"Row is Deletd");
		    } 
		    catch(Exception e) 
		    {
		    	
		     System.out.println("Not Deleted");
		     }
		 

		/*
		 * List l = t.getForObject(url+"/ms",List.class); System.out.println(l);
		 * System.out.println(l.size());
		 */
		
		
		/*
		 * Mobile z =new Mobile(2,22222); Mobile q
		 * =t.postForObject("http://localhost:7777/upd", z, Mobile.class); //input //
		 * argument url, object you want to pass as input, return type classname
		 * System.out.println(q);
		 * 
		 */
		  
		  
		  
		  
		/*
		  List<Mobile> l = t.getForObject(url+"/msq?x=33333",List.class);
		   System.out.println(l);
		  
		  */
		 
		
		
		
		
		
		
		

	}

}
