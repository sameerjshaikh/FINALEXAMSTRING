package exam.hello;

import javax.persistence.Entity;
import javax.persistence.Id;


public class Emp {
	
	private int empno;
	private int deptid;
	public int salary;
}
