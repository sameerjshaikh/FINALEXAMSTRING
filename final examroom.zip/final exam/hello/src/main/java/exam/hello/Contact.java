package exam.hello;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Contact {
	
	private String name;
	private int pincode;
	
	
	
	@Id
	private int mobile;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public int getMbileno() {
		return mobile;
	}
	public void setMbileno(int mbileno) {
		this.mobile = mbileno;
	}
	@Override
	public String toString() {
		return "Contact [name=" + name + ", pincode=" + pincode + ", mobile=" + mobile + "]";
	}
	public Contact(String name, int pincode, int mbileno) {
		super();
		this.name = name;
		this.pincode = pincode;
		this.mobile = mbileno;
	}
	
	
	public Contact() {
	

		
	}
	
	
	}