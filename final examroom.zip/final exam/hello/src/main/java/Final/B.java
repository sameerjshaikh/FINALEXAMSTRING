package Final;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class B {
	
	private C obj1;
	
	
	@Autowired
	public void setObj1(C obj1) {
		System.out.println("Service : repository DAO  wired to service ");
		this.obj1 = obj1;
	}




	public B()
	{
		
		//System.out.println("B object created");
	}



	/*
	 * 
	 * //single select scenario public Device getDevice(int mn) { // note obj1 here
	 * is a repository object
	 * 
	 * Optional<Device> x = obj1.findById(mn); Device y =null; if(x.isPresent()) { y
	 * = x.get(); //get the Device object
	 * 
	 * } else {
	 * 
	 * } //logic is Device object iemi no is zero then Device no is not found.
	 * return y;
	 * 
	 * 
	 * 
	 * 
	 * }
	 */


	/*
	 * public Device updateDevice(Device n) { //
	 * System.out.println("update failure"); // TODO Auto-generated method stub
	 * if(obj1.existsById(n.getMn())) obj1.save(n); //change of failing is almost
	 * zero. else System.out.println("update failed"); return n; }
	 */



	/*
	 * public List<Device> getAll() { // TODO Auto-generated method stub return
	 * obj1.findAll(); }
	 * 
	 */

	/*
	 * public Device getDeviceOk(int imeino) { // TODO Auto-generated method stub
	 * return obj1.findOne(imeino); }
	 * 
	 */
	/*
	 * 
	 * public Device getNonID(int imeino) { // TODO Auto-generated method stub
	 * return obj1.findIMIE(imeino); }
	 * 
	 */


	public Device getdeletfun(int mn) {
		
		
		// TODO Auto-generated method stub
		
		
		Optional<Device> x = obj1.findById(mn);
		
		Device y =null;
		if(x.isPresent())
		{
			obj1.deleteById(mn);
			y=x.get();
		}
		else
		{
			System.out.println(" Id Not found");
			
		   
		
		}
		
		return y;
		
	}



	
	  public List<Device> getAllmsget(int status) {
	  
	 return obj1.selectms(status); 
	 }
	 




	/*
	 * public List<Device> getDevice(int deviceid) {
	 * 
	 * 
	 * 
	 * // TODO Auto-generated method stub return obj1.findid(deviceid); }
	 */
}
