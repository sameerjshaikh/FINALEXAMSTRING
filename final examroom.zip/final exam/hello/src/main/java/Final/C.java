package Final;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface C extends JpaRepository<Device, Integer> {

	
	/*
	 * @Query("FROM Device WHERE imeino = :x") Device findOne(@Param("x") int
	 * imeino);
	 * 
	 * @Query("FROM Device WHERE imeino = :x") Device findIMIE(@Param("x") int
	 * imeino);
	 * 
	 * //Device is entity class, Integer is primary key // hibernate will never work
	 * until you use concept called Primary key.
	 * 
	 * @Query("SELECT u FROM Device u WHERE u.imeino = 3") Collection<Device>
	 * findAllActiveUsers();
	 */ 
	  @Query("SELECT u FROM Device u WHERE u.status =:x")
	  List<Device> selectms(@Param("x") int status);
	 
	
	
	//@Query("FROM Device WHERE deviceid = :x")
	//List<Device> findid(@Param("x") int deviceid);
	
	
	
	
	/*
	 
	  //you dont need to write this if you got something else please go ahead and use it.
	  
	  //import delete should work and how it works it is left to you.
	  @Modifying
    @Query("delete from User u where u.firstName = ?1")
    void deleteUsersByFirstName(String firstName);

	  
	  
	 */
	

}
