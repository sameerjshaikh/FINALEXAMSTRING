package Final;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Device {
	@Id
	private int deviceid;
	private String devicename;
	private int status;
	public int getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(int deviceid) {
		deviceid = deviceid;
	}
	public String getDevicename() {
		return devicename;
	}
	public void setDevicename(String devicename) {
		devicename = devicename;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		status = status;
	}
	@Override
	public String toString() {
		return "Device [Deviceid=" + deviceid + ", Devicename=" + devicename + ", Status=" + status + "]";
	}
	public Device() {
		super();
		// TODO Auto-generated constructor stub
	}


}
