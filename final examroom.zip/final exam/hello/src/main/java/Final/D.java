package Final;

import java.util.List;

import org.springframework.web.client.RestTemplate;

public class D {

	
	//please before running D.java ensure server is running.
	
	public static void main(String[] args) {
		// suppose postman goes to post office
	//	String url ="http://localhost:7700/aoinhypsdpoc";
		RestTemplate t =new RestTemplate();
	/*	
		Circle c = new Circle();  //input
		c.setRadius(3);
		Rectangle r = t.postForObject(url, c, Rectangle.class);
		System.out.println(r.getLength());
		
		 */
		
		  String url ="http://localhost:7777";
		  
		  
		  
		/*
		 * List<Device> x = t.getForObject(url+"/pw?x=1",List.class);
		 * System.out.println(x);
		 * 
		 * 
		 */
		  
		
		/*
		 * Device x = t.getForObject(url+"/non?x=33333",Device.class);
		 * System.out.println(x.getMn());
		 */
		
		
		
		  //for delete
		
		/*
		 * try { Device x =t.getForObject(url+"/del?x=1",Device.class);
		 * System.out.println("This "+ x +"Row is Deletd"); } catch(Exception e) {
		 * 
		 * System.out.println("Not Deleted"); }
		 */

		/*
		 * List l = t.getForObject(url+"/ms",List.class); System.out.println(l);
		 * System.out.println(l.size());
		 */
		
		
		/*
		 * Device z =new Device(2,22222); Device q
		 * =t.postForObject("http://localhost:7777/upd", z, Device.class); //input //
		 * argument url, object you want to pass as input, return type classname
		 * System.out.println(q);
		 * 
		 */
		  
		  
		  
		  
		
		  List<Device> l = t.getForObject(url+"/msq?x=5",List.class);
		   System.out.println(l);
		  
		  
		 
		
		
		
		
		
		
		

	}

}
