package oops.basics;

public class TestA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object o = "hello";
		//here reference is of type object.
		// I want what type of Object is the reference pointing to.
		
		if(o instanceof String)  //Are you this, Are you that ...
		{ 
			System.out.println("true we got string");
			
		}
		
		Class c = o.getClass();
		System.out.println(c.getName()) ;  // who are you
		
		
		
		A obj =new A();
		System.out.println(obj);

	}

}
