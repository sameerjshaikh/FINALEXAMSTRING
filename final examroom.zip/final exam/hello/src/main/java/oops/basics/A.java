package oops.basics;

public class A {

	@Override
	public String toString() {
		return "A []";
	}
	
	

}
