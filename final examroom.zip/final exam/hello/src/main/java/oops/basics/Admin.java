package oops.basics;

public class Admin extends Emp {

	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("manage facilities");
	}
	
	

}
