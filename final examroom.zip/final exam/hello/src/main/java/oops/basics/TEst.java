package oops.basics;

class A extends Exception
{
	
}

class B extends RuntimeException
{
	
	
}

public class TEst {
	
	private static void personB() throws A{
		// TODO Auto-generated method stub
		
	}
	
	
	private static void personA() throws A  {
		// TODO Auto-generated method stub
		personB();
		
	}

	public static void main(String[] args) {
		

		try {
			personA();
		} catch (A e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		if(args.length == 0)
			throw new B();
		try
		{
			
			
		}catch(B temp)
		{
			
		}
		
		
		
		/*
		 * if(args.length == 0); throw new A();
		 */
		
		/*
		 * try { System.out.println("stupdiity never ends");
		 * 
		 * }catch(A temp) { System.out.println("ok"); }
		 */		
	}


}





