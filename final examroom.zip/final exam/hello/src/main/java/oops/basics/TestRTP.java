package oops.basics;

public class TestRTP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Emp e =null;
		int x =(int)(Math.random()*10);
		if (x <5 )
				e =new SE();
		else
				e =new Admin();
		e.swipecard();  //not runtime polymoprphism becuase final function call.
		e.work();  //rntime polymorphism.  -- made the need for using instanceof

		if (e instanceof SE) {
			SE temp = (SE) e; //( typecasting super class ref to subclass ref)
			//to access exclusive functions of the subclass
			temp.projectMeeting();
		}
		
		
		
		
		
		//requirmenet goes like this, incase you got SE , please ask him to attend project
		//meeting
		
		
		
		
		
		
		

	}

}
