package oops.basics;

public class Emp {

	public final void swipecard() {
		// TODO Auto-generated method stub
		System.out.println("swipe the card");
		
	}

	public void work() {
		// TODO Auto-generated method stub
		System.out.println("walk around");
		
	}

}
