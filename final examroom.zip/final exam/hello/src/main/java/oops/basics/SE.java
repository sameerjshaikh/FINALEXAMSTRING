package oops.basics;

public class SE extends Emp {

	@Override
	public void work() {
		// TODO Auto-generated method stub
		System.out.println("standup and sitdown");
	}
	
	public void projectMeeting()
	{
		System.out.println("project meeting for SE");
	}
	
	

}
